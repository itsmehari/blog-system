<?php
require_once 'includes/db.php';

$slug = $_GET['slug'] ?? '';
if (!$slug) die('Post not specified.');

$stmt = $conn->prepare("SELECT p.*, a.name AS author_name, a.bio, a.profile_img, c.name AS category_name, c.slug AS category_slug FROM blog_posts p LEFT JOIN blog_authors a ON p.author_id = a.id LEFT JOIN blog_categories c ON p.category_id = c.id WHERE p.slug = ? AND p.status = 'published' LIMIT 1");
$stmt->bind_param("s", $slug);
$stmt->execute();
$post = $stmt->get_result()->fetch_assoc();

if (!$post) die('Post not found.');

$readTime = ceil(str_word_count(strip_tags($post['content'])) / 200);
$pageTitle = $post['title'] . " - BSERI Blog";
$pageHeading = "Article";
$og = [
  'title' => $post['title'],
  'description' => substr(strip_tags($post['content']), 0, 150),
  'image' => 'https://' . $_SERVER['HTTP_HOST'] . '/uploads/' . basename($post['featured_img']),
  'url' => 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']
];

include 'includes/head.php';
include 'includes/header.php';
?>

<nav class="breadcrumb">
  <a href="index.php">Home</a> ›
  <a href="category.php?slug=<?= $post['category_slug'] ?>"><?= $post['category_name'] ?></a> ›
  <span><?= htmlspecialchars($post['title']) ?></span>
</nav>

<h1 class="post-title"><?= htmlspecialchars($post['title']) ?></h1>
<div class="post-meta">
  By <?= htmlspecialchars($post['author_name']) ?> |
  <?= date('M d, Y', strtotime($post['created_at'])) ?> |
  <?= $readTime ?> min read |
  Category: <a href="category.php?slug=<?= $post['category_slug'] ?>"><?= $post['category_name'] ?></a>
</div>

<?php if ($post['featured_img']): ?>
  <img src="uploads/<?= basename($post['featured_img']) ?>" class="post-cover" alt="<?= htmlspecialchars($post['title']) ?>">
<?php endif; ?>

<article class="post-content"><?= $post['content'] ?></article>

<?php include 'includes/footer.php'; ?>
