<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'metap8ok_besriadmin');
define('DB_PASS', 'Mylapore@21g');
define('DB_NAME', 'metap8ok_bseriblog');
?>
