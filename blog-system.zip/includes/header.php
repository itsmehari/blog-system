<header class="site-header">
  <img src="assets/images/bseri-logo.png" alt="BSERI Logo" class="logo">
  <button id="theme-toggle" class="read-more-btn" style="float:right;">🌓 Toggle Theme</button>
  <h1><?= $pageHeading ?? 'BSERI Blog' ?></h1>
</header>
